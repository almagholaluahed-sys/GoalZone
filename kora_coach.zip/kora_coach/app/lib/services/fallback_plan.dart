import '../catalog.dart';
import '../models.dart';

/// Builds a plan on the phone, with no internet and no AI, from the built-in exercise library.
/// Used when the server is unreachable (or not configured yet), so the app never ends up empty.
class FallbackPlanner {
  static const Map<int, List<int>> _patterns = {
    3: [1, 3, 5],
    4: [1, 2, 4, 6],
    5: [1, 2, 4, 5, 6],
    6: [1, 2, 3, 5, 6, 7],
  };

  static const List<String> _tips = [
    '화이팅! أنت تقدر 💪',
    'خطوة صغيرة كل يوم تصنع نجماً ⭐',
    'ركّز على الجودة قبل السرعة 🎯',
    'اشرب الماء قبل التمرين وبعده 💧',
    'حافظ على ظهرك مستقيماً وعينيك للأمام 👀',
    'استمر! لا تتوقف عند أول تعب 🔥',
    'اللمسة الأولى الجيدة نصف الحل ⚽',
  ];

  static int _hash(String s) =>
      s.codeUnits.fold(0, (a, b) => (a * 31 + b) & 0x7fffffff);

  static int _clampInt(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

  static int _round5(int v) {
    final r = ((v + 2) ~/ 5) * 5;
    return r < 5 ? 5 : r;
  }

  static List<bool> trainingDays(Profile p) {
    if (p.planType == 'daily') return [true];
    final pattern = _patterns[p.daysPerWeek] ?? _patterns[4]!;
    return List<bool>.generate(14, (i) => pattern.contains((i % 7) + 1));
  }

  static List<Exercise> _eligible(Profile p, List<Exercise> all) {
    return all.where((e) {
      if (p.age < e.minAge) return false;
      if (p.levelNum < e.minLevel) return false;
      for (final q in e.equip) {
        if (!p.equipment.contains(q)) return false;
      }
      return e.positions.contains('all') || e.positions.contains(p.position);
    }).toList();
  }

  static Task _task(Exercise e, int minutes, String dose, int seed) {
    return Task(
      id: e.id,
      name: e.name,
      cat: e.cat,
      minutes: minutes,
      dose: dose,
      how: e.how,
      tip: _tips[(_hash(e.id) + seed) % _tips.length],
    );
  }

  static Plan build(Profile p, List<Exercise> all) {
    final eligible = _eligible(p, all);
    final warmups = eligible.where((e) => e.cat == 'warmup').toList();
    final recovery = eligible.where((e) => e.cat == 'recovery').toList();
    final walkList = all.where((e) => e.id == 'light_recovery_walk').toList();
    final mains = eligible
        .where((e) =>
            e.cat == 'technique' || e.cat == 'position' || e.cat == 'fitness')
        .toList();

    final train = trainingDays(p);
    final warmMin = p.sessionMinutes <= 30 ? 5 : (p.sessionMinutes <= 45 ? 8 : 10);
    final coolMin = p.sessionMinutes <= 30 ? 5 : 8;
    final budget = p.sessionMinutes - warmMin - coolMin;

    final days = <DayPlan>[];
    for (var d = 1; d <= train.length; d++) {
      if (!train[d - 1]) {
        days.add(DayPlan(
          day: d,
          rest: true,
          focus: 'يوم راحة 😴',
          tasks: walkList.isEmpty
              ? <Task>[]
              : [_task(walkList.first, walkList.first.minutes, '${walkList.first.minutes} دقيقة', d)],
        ));
        continue;
      }

      double score(Exercise e) {
        var s = 0.0;
        if (p.goal == 'all') {
          s += 1.5;
        } else if (e.goals.contains(p.goal)) {
          s += 2.5;
        } else {
          s += 0.3;
        }
        if (e.cat == 'position') s += 1.5;
        s += ((_hash(e.id) + d * 7919) % 100) / 100.0 * 2.0;
        return s;
      }

      final ranked = List<Exercise>.from(mains)
        ..sort((a, b) => score(b).compareTo(score(a)));

      final count = _clampInt((budget / 12).round(), 2, 4);
      final picked = <Exercise>[];
      var high = 0;
      for (final e in ranked) {
        if (picked.length >= count) break;
        if (e.intensity >= 3 && high >= 1) continue;
        picked.add(e);
        if (e.intensity >= 3) high++;
      }
      if (picked.length < 2) {
        for (final e in ranked) {
          if (picked.length >= 2) break;
          if (!picked.contains(e)) picked.add(e);
        }
      }

      // Split the main budget between the picked exercises in 5-minute steps.
      final mins = <int>[];
      var left = budget;
      for (var i = 0; i < picked.length; i++) {
        final slots = picked.length - i;
        if (slots == 1) {
          mins.add(left < 5 ? 5 : left);
        } else {
          var m = _round5(left ~/ slots);
          final maxAllowed = left - 5 * (slots - 1);
          if (m > maxAllowed) m = maxAllowed;
          if (m < 5) m = 5;
          mins.add(m);
          left -= m;
        }
      }

      final tasks = <Task>[];
      if (warmups.isNotEmpty) {
        final w = warmups[(d - 1) % warmups.length];
        tasks.add(_task(w, warmMin, '$warmMin دقيقة', d));
      }
      for (var i = 0; i < picked.length; i++) {
        tasks.add(_task(picked[i], mins[i], '${mins[i]} دقيقة', d + i));
      }
      if (recovery.isNotEmpty) {
        tasks.add(_task(recovery.first, coolMin, '$coolMin دقيقة', d));
      }

      final hasFitness = picked.any((e) => e.cat == 'fitness');
      final hasSkill = picked.any((e) => e.cat != 'fitness');
      final focus = hasFitness && hasSkill
          ? 'مهارة ولياقة'
          : (hasFitness ? 'لياقة وسرعة' : 'مهارة وتحكم');

      days.add(DayPlan(day: d, rest: false, focus: focus, tasks: tasks));
    }

    return Plan(
      title: p.planType == 'daily'
          ? 'خطة اليوم مع كوتش مين'
          : 'خطة أسبوعين مع كوتش مين',
      coachNote: '화이팅! خطة بسيطة والالتزام بها يصنع الفارق 💪',
      days: days,
      source: 'offline',
      createdAt: DateTime.now(),
    );
  }
}
