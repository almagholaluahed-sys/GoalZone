import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';

/// App state saved on the phone: profile, current plan, finished tasks, points and streak.
class AppStore extends ChangeNotifier {
  late SharedPreferences _prefs;

  Profile? profile;
  Plan? plan;
  Set<String> done = <String>{};
  int xp = 0;
  int streak = 0;
  String lastActive = '';

  /// One-time message shown by the plan screen (for example "offline plan used").
  String? notice;

  static const List<String> levelTitles = [
    'مبتدئ · 신인',
    'موهوب · 유망주',
    'نجم · 스타',
    'محترف · 프로',
    'أسطورة · 레전드',
  ];

  int get level => xp ~/ 100;
  int get xpInLevel => xp % 100;
  String get levelTitle =>
      levelTitles[level >= levelTitles.length ? levelTitles.length - 1 : level];

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final p = _prefs.getString('profile');
    if (p != null) {
      try {
        profile = Profile.fromJson(jsonDecode(p) as Map<String, dynamic>);
      } catch (_) {
        profile = null;
      }
    }
    final pl = _prefs.getString('plan');
    if (pl != null) {
      try {
        plan = Plan.fromJson(jsonDecode(pl) as Map<String, dynamic>);
      } catch (_) {
        plan = null;
      }
    }
    done = (_prefs.getStringList('done') ?? <String>[]).toSet();
    xp = _prefs.getInt('xp') ?? 0;
    streak = _prefs.getInt('streak') ?? 0;
    lastActive = _prefs.getString('lastActive') ?? '';
  }

  Future<void> saveProfile(Profile p) async {
    profile = p;
    await _prefs.setString('profile', jsonEncode(p.toJson()));
  }

  Future<void> setPlan(Plan newPlan) async {
    plan = newPlan;
    done = <String>{};
    await _persist();
    notifyListeners();
  }

  Future<void> resetPlan() async {
    plan = null;
    done = <String>{};
    await _prefs.remove('plan');
    await _prefs.setStringList('done', <String>[]);
    notifyListeners();
  }

  Future<void> _persist() async {
    final p = plan;
    if (p != null) {
      await _prefs.setString('plan', jsonEncode(p.toJson()));
    }
    await _prefs.setStringList('done', done.toList());
    await _prefs.setInt('xp', xp);
    await _prefs.setInt('streak', streak);
    await _prefs.setString('lastActive', lastActive);
  }

  bool isDone(int day, int index) => done.contains('d$day-t$index');

  int doneCount(DayPlan day) {
    var n = 0;
    for (var i = 0; i < day.tasks.length; i++) {
      if (isDone(day.day, i)) n++;
    }
    return n;
  }

  bool dayComplete(DayPlan day) =>
      day.tasks.isNotEmpty && doneCount(day) == day.tasks.length;

  double get overallProgress {
    final p = plan;
    if (p == null) return 0;
    var total = 0;
    var finished = 0;
    for (final day in p.days) {
      for (var i = 0; i < day.tasks.length; i++) {
        total++;
        if (isDone(day.day, i)) finished++;
      }
    }
    return total == 0 ? 0 : finished / total;
  }

  String _ymd(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void _touchStreak() {
    final now = DateTime.now();
    final today = _ymd(now);
    if (lastActive == today) return;
    final yesterday = _ymd(now.subtract(const Duration(days: 1)));
    streak = lastActive == yesterday ? streak + 1 : 1;
    lastActive = today;
  }

  /// Ticks or unticks a task. Returns true when this tick finished the whole day (bonus points).
  bool toggleTask(int day, int index) {
    final key = 'd$day-t$index';
    var dayJustCompleted = false;
    if (done.contains(key)) {
      done.remove(key);
      xp = xp >= 10 ? xp - 10 : 0;
    } else {
      done.add(key);
      xp += 10;
      _touchStreak();
      final p = plan;
      if (p != null) {
        final d = p.days.firstWhere((e) => e.day == day);
        if (dayComplete(d) && !done.contains('bonus-d$day')) {
          done.add('bonus-d$day');
          xp += 20;
          dayJustCompleted = true;
        }
      }
    }
    _persist();
    notifyListeners();
    return dayJustCompleted;
  }
}
