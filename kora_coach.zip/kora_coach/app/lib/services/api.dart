import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config.dart';
import '../models.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);

  @override
  String toString() => message;
}

class PlanApi {
  static bool get configured => kApiBase.isNotEmpty;

  /// Asks the server (which holds the Gemini key) for a plan.
  /// Throws on any failure so the caller can fall back to the offline planner.
  static Future<Plan> generate(Profile p) async {
    if (!configured) throw ApiException('API_BASE is not set');
    final base = kApiBase.endsWith('/')
        ? kApiBase.substring(0, kApiBase.length - 1)
        : kApiBase;
    final res = await http
        .post(
          Uri.parse('$base/plan'),
          headers: {
            'content-type': 'application/json',
            if (kAppKey.isNotEmpty) 'x-app-key': kAppKey,
          },
          body: jsonEncode(p.toJson()),
        )
        .timeout(const Duration(seconds: 90));
    if (res.statusCode != 200) {
      throw ApiException('server returned ${res.statusCode}');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    return Plan.fromJson(data['plan'] as Map<String, dynamic>, source: 'ai');
  }
}
