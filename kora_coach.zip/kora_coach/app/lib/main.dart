import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/onboarding_screen.dart';
import 'screens/plan_screen.dart';
import 'services/store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.init();
  runApp(KoraCoachApp(store: store));
}

class KoraCoachApp extends StatelessWidget {
  final AppStore store;
  const KoraCoachApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'كوتش مين',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: ListenableBuilder(
        listenable: store,
        builder: (context, _) => store.plan == null
            ? OnboardingScreen(store: store)
            : PlanScreen(store: store),
      ),
    );
  }
}
