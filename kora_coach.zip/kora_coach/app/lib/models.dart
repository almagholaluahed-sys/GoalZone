class Profile {
  final int age;
  final String position; // gk, def, mid, att
  final String level; // beginner, intermediate, advanced
  final String goal; // all, technique, fitness, speed, shooting
  final String planType; // daily, twoWeeks
  final int daysPerWeek; // 3..6 (used for twoWeeks)
  final int sessionMinutes; // 30, 45, 60, 90
  final List<String> equipment; // cones, wall, ladder, gym

  const Profile({
    required this.age,
    required this.position,
    required this.level,
    required this.goal,
    required this.planType,
    required this.daysPerWeek,
    required this.sessionMinutes,
    required this.equipment,
  });

  int get levelNum {
    switch (level) {
      case 'advanced':
        return 3;
      case 'intermediate':
        return 2;
      default:
        return 1;
    }
  }

  Map<String, dynamic> toJson() => {
        'age': age,
        'position': position,
        'level': level,
        'goal': goal,
        'planType': planType,
        'daysPerWeek': daysPerWeek,
        'sessionMinutes': sessionMinutes,
        'equipment': equipment,
      };

  factory Profile.fromJson(Map<String, dynamic> j) => Profile(
        age: (j['age'] as num).toInt(),
        position: j['position'] as String,
        level: j['level'] as String,
        goal: j['goal'] as String,
        planType: j['planType'] as String,
        daysPerWeek: (j['daysPerWeek'] as num).toInt(),
        sessionMinutes: (j['sessionMinutes'] as num).toInt(),
        equipment: List<String>.from(j['equipment'] as List),
      );
}

class Task {
  final String id;
  final String name;
  final String cat;
  final int minutes;
  final String dose;
  final String how;
  final String tip;

  const Task({
    required this.id,
    required this.name,
    required this.cat,
    required this.minutes,
    required this.dose,
    required this.how,
    required this.tip,
  });

  String get subtitle {
    if (dose.isEmpty) return '$minutes دقيقة';
    if (dose.contains('دقيقة') || dose.contains('دقائق')) return dose;
    return '$minutes د • $dose';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'cat': cat,
        'minutes': minutes,
        'dose': dose,
        'how': how,
        'tip': tip,
      };

  factory Task.fromJson(Map<String, dynamic> j) => Task(
        id: j['id'] as String,
        name: j['name'] as String,
        cat: (j['cat'] as String?) ?? '',
        minutes: (j['minutes'] as num).toInt(),
        dose: (j['dose'] as String?) ?? '',
        how: (j['how'] as String?) ?? '',
        tip: (j['tip'] as String?) ?? '',
      );
}

class DayPlan {
  final int day;
  final bool rest;
  final String focus;
  final List<Task> tasks;

  const DayPlan({
    required this.day,
    required this.rest,
    required this.focus,
    required this.tasks,
  });

  Map<String, dynamic> toJson() => {
        'day': day,
        'rest': rest,
        'focus': focus,
        'tasks': tasks.map((t) => t.toJson()).toList(),
      };

  factory DayPlan.fromJson(Map<String, dynamic> j) => DayPlan(
        day: (j['day'] as num).toInt(),
        rest: (j['rest'] as bool?) ?? false,
        focus: (j['focus'] as String?) ?? '',
        tasks: (j['tasks'] as List)
            .map((e) => Task.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

class Plan {
  final String title;
  final String coachNote;
  final List<DayPlan> days;
  final String source; // ai | offline
  final DateTime createdAt;

  const Plan({
    required this.title,
    required this.coachNote,
    required this.days,
    required this.source,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'coachNote': coachNote,
        'days': days.map((d) => d.toJson()).toList(),
        'source': source,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Plan.fromJson(Map<String, dynamic> j, {String? source}) => Plan(
        title: (j['title'] as String?) ?? 'خطتك مع كوتش مين',
        coachNote: (j['coachNote'] as String?) ?? '',
        days: (j['days'] as List)
            .map((e) => DayPlan.fromJson(e as Map<String, dynamic>))
            .toList(),
        source: source ?? (j['source'] as String?) ?? 'ai',
        createdAt: j['createdAt'] != null
            ? DateTime.parse(j['createdAt'] as String)
            : DateTime.now(),
      );
}
