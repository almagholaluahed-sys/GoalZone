import 'package:flutter/material.dart';

import 'theme.dart';

/// Coach Min: an original character, shown as a round avatar with a speech bubble.
class CoachHeader extends StatelessWidget {
  final String message;
  const CoachHeader({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [kPink, kLavender],
            ),
            boxShadow: [BoxShadow(color: kShadow, blurRadius: 12, offset: Offset(0, 4))],
          ),
          alignment: Alignment.center,
          child: const Text('🧢', style: TextStyle(fontSize: 32)),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(4),
              ),
              boxShadow: const [BoxShadow(color: kShadow, blurRadius: 10, offset: Offset(0, 3))],
            ),
            child: Text(
              message,
              style: const TextStyle(color: kInk, fontSize: 15, height: 1.5, fontWeight: FontWeight.w600),
            ),
          ),
        ),
      ],
    );
  }
}

/// A rounded white card with a title, used for each question in the form.
class SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const SectionCard({super.key, required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [BoxShadow(color: kShadow, blurRadius: 12, offset: Offset(0, 4))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: kInk, fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}
