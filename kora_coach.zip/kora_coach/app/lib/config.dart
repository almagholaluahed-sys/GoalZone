// Set at build time:
//   flutter build apk --release --dart-define=API_BASE=https://your-worker.workers.dev --dart-define=APP_KEY=your-key
// If API_BASE is empty the app still works: it builds plans offline from its built-in exercise library.
const String kApiBase = String.fromEnvironment('API_BASE', defaultValue: '');
const String kAppKey = String.fromEnvironment('APP_KEY', defaultValue: '');
