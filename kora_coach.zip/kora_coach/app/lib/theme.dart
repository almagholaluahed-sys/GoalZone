import 'package:flutter/material.dart';

// K-style pastel palette.
const Color kPink = Color(0xFFFF8FAB);
const Color kLavender = Color(0xFFB79CED);
const Color kPurple = Color(0xFF8E6FE0);
const Color kMint = Color(0xFF6FD3B4);
const Color kMintSoft = Color(0xFFE9F8F2);
const Color kInk = Color(0xFF2D2A4A);
const Color kInkSoft = Color(0xFF6E6A8C);
const Color kCream = Color(0xFFFFF8F3);
const Color kLavenderSoft = Color(0xFFF1EBFC);
const Color kShadow = Color(0x14000000);

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kPurple,
    brightness: Brightness.light,
  ).copyWith(primary: kPurple, secondary: kPink);

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: kCream,
    appBarTheme: const AppBarTheme(
      backgroundColor: kCream,
      foregroundColor: kInk,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(
        color: kInk,
        fontSize: 20,
        fontWeight: FontWeight.w800,
      ),
    ),
    chipTheme: const ChipThemeData(
      shape: StadiumBorder(),
      selectedColor: kLavenderSoft,
      backgroundColor: Colors.white,
      labelStyle: TextStyle(color: kInk, fontWeight: FontWeight.w600),
    ),
  );
}
