import 'package:flutter/material.dart';

import '../models.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets.dart';

class PlanScreen extends StatefulWidget {
  final AppStore store;
  const PlanScreen({super.key, required this.store});

  @override
  State<PlanScreen> createState() => _PlanScreenState();
}

class _PlanScreenState extends State<PlanScreen> {
  late int _day;

  @override
  void initState() {
    super.initState();
    final plan = widget.store.plan!;
    final start = DateTime(plan.createdAt.year, plan.createdAt.month, plan.createdAt.day);
    final elapsed = DateTime.now().difference(start).inDays + 1;
    final last = plan.days.length;
    _day = elapsed < 1 ? 1 : (elapsed > last ? last : elapsed);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final n = widget.store.notice;
      if (n != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(n)));
        widget.store.notice = null;
      }
    });
  }

  void _toggle(DayPlan day, int index) {
    final completed = widget.store.toggleTask(day.day, index);
    if (completed) _celebrate();
  }

  void _celebrate() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: 1),
              duration: const Duration(milliseconds: 700),
              curve: Curves.elasticOut,
              builder: (context, v, child) => Transform.scale(scale: v, child: child),
              child: const Text('🎉', style: TextStyle(fontSize: 64)),
            ),
            const SizedBox(height: 8),
            const Text('أحسنت يا بطل!',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 6),
            const Text('أنهيت تدريب اليوم كاملاً، وحصلت على +20 نقطة إضافية ⭐',
                textAlign: TextAlign.center, style: TextStyle(color: kInkSoft, height: 1.5)),
            const SizedBox(height: 6),
            const Text('화이팅!', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: kPurple)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('تابع')),
        ],
      ),
    );
  }

  Future<void> _newPlan() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إنشاء خطة جديدة؟'),
        content: const Text('ستُستبدل الخطة الحالية، لكن نقاطك ومستواك يبقيان كما هما.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('نعم، خطة جديدة')),
        ],
      ),
    );
    if (ok == true) await widget.store.resetPlan();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) {
        final store = widget.store;
        final plan = store.plan;
        if (plan == null) return const SizedBox.shrink();
        final day = plan.days.firstWhere((d) => d.day == _day, orElse: () => plan.days.first);

        return Scaffold(
          appBar: AppBar(
            title: Text(plan.title),
            actions: [
              IconButton(
                tooltip: 'خطة جديدة',
                icon: const Icon(Icons.autorenew),
                onPressed: _newPlan,
              ),
            ],
          ),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
              children: [
                _statsCard(store),
                const SizedBox(height: 14),
                if (plan.coachNote.isNotEmpty) CoachHeader(message: plan.coachNote),
                if (plan.source == 'offline')
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text('خطة بدون إنترنت (قوالب جاهزة)',
                        style: TextStyle(color: kInkSoft, fontSize: 12)),
                  ),
                const SizedBox(height: 14),
                if (plan.days.length > 1) _dayChips(plan, store),
                if (plan.days.length > 1) const SizedBox(height: 14),
                _dayHeader(day, store),
                const SizedBox(height: 10),
                if (day.rest) _restCard(),
                for (var i = 0; i < day.tasks.length; i++) _taskCard(day, i, store),
                const SizedBox(height: 12),
                const Text(
                  'هذه الخطة إرشادية. توقّف فوراً عند الشعور بألم، واستشر مدرباً أو طبيباً عند الحاجة.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: kInkSoft, fontSize: 12, height: 1.5),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _statsCard(AppStore store) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [kPurple, kPink],
        ),
        boxShadow: const [BoxShadow(color: kShadow, blurRadius: 14, offset: Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'المستوى ${store.level + 1} · ${store.levelTitle}',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16),
                ),
              ),
              Text('🔥 ${store.streak}',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
            ],
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: store.xpInLevel / 100,
            minHeight: 10,
            borderRadius: BorderRadius.circular(8),
            backgroundColor: const Color(0x55FFFFFF),
            color: Colors.white,
          ),
          const SizedBox(height: 6),
          Text(
            '${store.xpInLevel}/100 نقطة • إنجاز الخطة ${(store.overallProgress * 100).round()}%',
            style: const TextStyle(color: Colors.white, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _dayChips(Plan plan, AppStore store) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: plan.days.length,
        separatorBuilder: (context, i) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final d = plan.days[i];
          final icon = d.rest ? '😴' : (store.dayComplete(d) ? '✅' : '🏃');
          return ChoiceChip(
            label: Text('$icon يوم ${d.day}'),
            selected: d.day == _day,
            onSelected: (_) => setState(() => _day = d.day),
          );
        },
      ),
    );
  }

  Widget _dayHeader(DayPlan day, AppStore store) {
    final total = day.tasks.length;
    return Row(
      children: [
        Expanded(
          child: Text(
            'يوم ${day.day} · ${day.focus}',
            style: const TextStyle(color: kInk, fontSize: 18, fontWeight: FontWeight.w800),
          ),
        ),
        if (total > 0)
          Text('${store.doneCount(day)}/$total',
              style: const TextStyle(color: kPurple, fontWeight: FontWeight.w800, fontSize: 16)),
      ],
    );
  }

  Widget _restCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kLavenderSoft,
        borderRadius: BorderRadius.circular(20),
      ),
      child: const Text(
        '😴 اليوم راحة. العضلات تنمو أثناء الراحة وليس أثناء التمرين فقط. نم جيداً واشرب الماء، ويمكنك المشي الخفيف إن أحببت.',
        style: TextStyle(color: kInk, height: 1.6, fontWeight: FontWeight.w600),
      ),
    );
  }

  Widget _taskCard(DayPlan day, int i, AppStore store) {
    final t = day.tasks[i];
    final done = store.isDone(day.day, i);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: done ? kMintSoft : Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: kShadow, blurRadius: 10, offset: Offset(0, 3))],
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          expandedCrossAxisAlignment: CrossAxisAlignment.start,
          leading: Checkbox(
            value: done,
            shape: const CircleBorder(),
            activeColor: kMint,
            onChanged: (_) => _toggle(day, i),
          ),
          title: Text(
            t.name,
            style: TextStyle(
              color: kInk,
              fontWeight: FontWeight.w700,
              decoration: done ? TextDecoration.lineThrough : null,
            ),
          ),
          subtitle: Text(t.subtitle, style: const TextStyle(color: kInkSoft)),
          children: [
            Text(t.how, style: const TextStyle(color: kInk, height: 1.6)),
            if (t.tip.isNotEmpty) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: kLavenderSoft,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text('🧢 كوتش مين: ${t.tip}',
                    style: const TextStyle(color: kInk, fontWeight: FontWeight.w600, height: 1.5)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
