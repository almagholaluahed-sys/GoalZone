import 'dart:async';

import 'package:flutter/material.dart';

import '../catalog.dart';
import '../models.dart';
import '../services/api.dart';
import '../services/fallback_plan.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets.dart';

const Map<String, String> _positions = {
  'gk': '🧤 حارس مرمى',
  'def': '🛡️ مدافع',
  'mid': '🎯 لاعب وسط',
  'att': '⚡ مهاجم',
};
const Map<String, String> _levels = {
  'beginner': '🌱 مبتدئ',
  'intermediate': '🔥 متوسط',
  'advanced': '🏆 متقدم',
};
const Map<String, String> _goals = {
  'all': '⭐ تطوير شامل',
  'technique': '🎨 المهارة والتحكم',
  'fitness': '💪 اللياقة والقوة',
  'speed': '🚀 السرعة والرشاقة',
  'shooting': '🥅 التسديد',
};
const Map<String, String> _equipment = {
  'cones': 'أقماع',
  'wall': 'حائط للتمرير',
  'ladder': 'سلم رشاقة',
  'gym': 'صالة أثقال',
};
const List<int> _sessionOptions = [30, 45, 60, 90];

const List<String> _loadingMessages = [
  'كوتش مين يدرس مستواك… 🧐',
  'يختار لك أفضل التمارين… ⚽',
  'يوزّع الراحة والتعافي بذكاء… 😴',
  'لحظات ويكون جدولك جاهزاً… 화이팅!',
];

class OnboardingScreen extends StatefulWidget {
  final AppStore store;
  const OnboardingScreen({super.key, required this.store});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  double _age = 16;
  String _position = 'mid';
  String _level = 'beginner';
  String _goal = 'all';
  String _planType = 'daily';
  int _daysPerWeek = 4;
  int _sessionMinutes = 60;
  final Set<String> _gear = <String>{};

  bool _loading = false;
  int _msgIndex = 0;
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    final p = widget.store.profile;
    if (p != null) {
      _age = p.age.toDouble().clamp(8, 45).toDouble();
      _position = p.position;
      _level = p.level;
      _goal = p.goal;
      _planType = p.planType;
      _daysPerWeek = p.daysPerWeek;
      _sessionMinutes = p.sessionMinutes;
      _gear.addAll(p.equipment);
    }
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  Widget _chips(Map<String, String> options, String selected, void Function(String) onPick) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: options.entries
          .map((e) => ChoiceChip(
                label: Text(e.value),
                selected: selected == e.key,
                onSelected: (_) => setState(() => onPick(e.key)),
              ))
          .toList(),
    );
  }

  Future<void> _submit() async {
    final profile = Profile(
      age: _age.round(),
      position: _position,
      level: _level,
      goal: _goal,
      planType: _planType,
      daysPerWeek: _daysPerWeek,
      sessionMinutes: _sessionMinutes,
      equipment: _gear.toList(),
    );

    setState(() {
      _loading = true;
      _msgIndex = 0;
    });
    _ticker = Timer.periodic(const Duration(seconds: 3), (_) {
      if (mounted) setState(() => _msgIndex = (_msgIndex + 1) % _loadingMessages.length);
    });

    Plan plan;
    String? notice;
    try {
      plan = await PlanApi.generate(profile);
    } catch (_) {
      final catalog = await Catalog.load();
      plan = FallbackPlanner.build(profile, catalog);
      if (PlanApi.configured) {
        notice = 'تعذّر الاتصال بالمدرب الذكي، فجهّزنا لك خطة احتياطية بدون إنترنت.';
      }
    }

    _ticker?.cancel();
    widget.store.notice = notice;
    await widget.store.saveProfile(profile);
    await widget.store.setPlan(plan);
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('كوتش مين ⚽')),
      body: Stack(
        children: [
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
              children: [
                const CoachHeader(
                  message: 'أهلاً يا بطل! أنا كوتش مين 👋 جاوب على الأسئلة وأجهّز لك خطة تناسبك. 화이팅!',
                ),
                const SizedBox(height: 18),
                SectionCard(
                  title: 'كم عمرك؟  ${_age.round()} سنة',
                  child: Slider(
                    value: _age,
                    min: 8,
                    max: 45,
                    divisions: 37,
                    label: '${_age.round()}',
                    onChanged: (v) => setState(() => _age = v),
                  ),
                ),
                SectionCard(
                  title: 'ما مركزك؟',
                  child: _chips(_positions, _position, (v) => _position = v),
                ),
                SectionCard(
                  title: 'ما مستواك؟',
                  child: _chips(_levels, _level, (v) => _level = v),
                ),
                SectionCard(
                  title: 'ما هدفك الأساسي؟',
                  child: _chips(_goals, _goal, (v) => _goal = v),
                ),
                SectionCard(
                  title: 'نوع الخطة',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: SegmentedButton<String>(
                          segments: const [
                            ButtonSegment<String>(value: 'daily', label: Text('خطة اليوم')),
                            ButtonSegment<String>(value: 'twoWeeks', label: Text('خطة أسبوعين')),
                          ],
                          selected: {_planType},
                          onSelectionChanged: (s) => setState(() => _planType = s.first),
                        ),
                      ),
                      if (_planType == 'twoWeeks') ...[
                        const SizedBox(height: 14),
                        const Text('كم يوماً تتدرب في الأسبوع؟',
                            style: TextStyle(color: kInkSoft, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          children: [3, 4, 5, 6]
                              .map((d) => ChoiceChip(
                                    label: Text('$d أيام'),
                                    selected: _daysPerWeek == d,
                                    onSelected: (_) => setState(() => _daysPerWeek = d),
                                  ))
                              .toList(),
                        ),
                      ],
                    ],
                  ),
                ),
                SectionCard(
                  title: 'مدة التمرين',
                  child: Wrap(
                    spacing: 8,
                    children: _sessionOptions
                        .map((m) => ChoiceChip(
                              label: Text('$m دقيقة'),
                              selected: _sessionMinutes == m,
                              onSelected: (_) => setState(() => _sessionMinutes = m),
                            ))
                        .toList(),
                  ),
                ),
                SectionCard(
                  title: 'ما المعدات المتاحة؟ (الكرة متوفرة دائماً)',
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _equipment.entries
                        .map((e) => FilterChip(
                              label: Text(e.value),
                              selected: _gear.contains(e.key),
                              onSelected: (on) => setState(() {
                                if (on) {
                                  _gear.add(e.key);
                                } else {
                                  _gear.remove(e.key);
                                }
                              }),
                            ))
                        .toList(),
                  ),
                ),
                const SizedBox(height: 4),
                SizedBox(
                  height: 56,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: kPurple,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                      textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                    onPressed: _loading ? null : _submit,
                    icon: const Icon(Icons.sports_soccer),
                    label: const Text('جهّز خطتي! 화이팅'),
                  ),
                ),
              ],
            ),
          ),
          if (_loading)
            Positioned.fill(
              child: Container(
                color: const Color(0xE6FFF8F3),
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircularProgressIndicator(color: kPurple),
                    const SizedBox(height: 20),
                    const Text('🧢', style: TextStyle(fontSize: 48)),
                    const SizedBox(height: 10),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 400),
                      child: Text(
                        _loadingMessages[_msgIndex],
                        key: ValueKey<int>(_msgIndex),
                        style: const TextStyle(color: kInk, fontSize: 17, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
