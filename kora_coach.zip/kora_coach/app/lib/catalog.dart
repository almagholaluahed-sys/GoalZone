import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

class Exercise {
  final String id;
  final String name;
  final String cat; // warmup, technique, position, fitness, recovery, rest
  final String how;
  final List<String> goals;
  final List<String> positions;
  final List<String> equip;
  final int minAge;
  final int minLevel;
  final int minutes;
  final int intensity;

  const Exercise({
    required this.id,
    required this.name,
    required this.cat,
    required this.how,
    required this.goals,
    required this.positions,
    required this.equip,
    required this.minAge,
    required this.minLevel,
    required this.minutes,
    required this.intensity,
  });

  factory Exercise.fromJson(Map<String, dynamic> j) => Exercise(
        id: j['id'] as String,
        name: j['name'] as String,
        cat: j['cat'] as String,
        how: j['how'] as String,
        goals: List<String>.from(j['goals'] as List),
        positions: List<String>.from(j['positions'] as List),
        equip: List<String>.from(j['equip'] as List),
        minAge: (j['minAge'] as num).toInt(),
        minLevel: (j['minLevel'] as num).toInt(),
        minutes: (j['minutes'] as num).toInt(),
        intensity: (j['intensity'] as num).toInt(),
      );
}

class Catalog {
  static List<Exercise>? _cache;

  static Future<List<Exercise>> load() async {
    final cached = _cache;
    if (cached != null) return cached;
    final raw = await rootBundle.loadString('assets/exercises.json');
    final list = (jsonDecode(raw) as List)
        .map((e) => Exercise.fromJson(e as Map<String, dynamic>))
        .toList();
    _cache = list;
    return list;
  }
}
