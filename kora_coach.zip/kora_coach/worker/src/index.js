import catalog from '../../shared/exercises.json' with { type: 'json' };
import { validateRequest, trainingDays, buildPrompt, parseJsonLoose, repairPlan } from './plan.js';

const MAX_ATTEMPTS = 3;
const HOURLY_LIMIT = 20; // per client IP, per worker instance (a light safety net, not a hard guarantee)
const hits = new Map();

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });
}

function rateLimited(ip) {
  const now = Date.now();
  const rec = hits.get(ip);
  if (!rec || now > rec.reset) {
    hits.set(ip, { count: 1, reset: now + 3600_000 });
    if (hits.size > 5000) hits.clear();
    return false;
  }
  rec.count += 1;
  return rec.count > HOURLY_LIMIT;
}

export async function callGemini(env, system, user, fetchFn = fetch) {
  const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const generationConfig = {
    temperature: 0.8,
    responseMimeType: 'application/json',
    maxOutputTokens: 20000,
  };
  // Turn off "thinking" on 2.5 Flash models: faster, cheaper, and plenty good for this task.
  if (model.includes('2.5-flash')) generationConfig.thinkingConfig = { thinkingBudget: 0 };

  const res = await fetchFn(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: user }] }],
      generationConfig,
    }),
  });
  if (!res.ok) {
    const err = new Error(`gemini_http_${res.status}`);
    err.status = res.status;
    throw err;
  }
  const data = await res.json();
  const parts = data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
  const text = Array.isArray(parts) ? parts.map((p) => p.text || '').join('') : '';
  if (!text) throw new Error('gemini_empty');
  return text;
}

export async function generatePlan(env, req, fetchFn = fetch) {
  const train = trainingDays(req);
  let problem = '';
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const { system, user } = buildPrompt(req, catalog, train, problem);
    try {
      const text = await callGemini(env, system, user, fetchFn);
      const raw = parseJsonLoose(text);
      if (!raw) {
        problem = 'the answer was not valid JSON';
        continue;
      }
      const fixed = repairPlan(raw, req, catalog, train);
      if (fixed.ok) return { ok: true, plan: fixed.plan };
      problem = fixed.reason;
    } catch (e) {
      // Quota / auth problems will not be fixed by retrying.
      if (e.status === 429 || e.status === 401 || e.status === 403 || e.status === 400) {
        return { ok: false, status: e.status === 429 ? 503 : 502, error: e.status === 429 ? 'ai_busy' : 'ai_error' };
      }
      problem = 'the AI service had a temporary error';
    }
  }
  return { ok: false, status: 502, error: 'generation_failed' };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'GET' && url.pathname === '/') return json({ ok: true, service: 'kora-coach-api' });
    if (request.method !== 'POST' || url.pathname !== '/plan') return json({ error: 'not_found' }, 404);

    if (env.APP_KEY && request.headers.get('x-app-key') !== env.APP_KEY) return json({ error: 'unauthorized' }, 401);
    if (!env.GEMINI_API_KEY) return json({ error: 'server_not_configured' }, 500);

    const ip = request.headers.get('cf-connecting-ip') || 'unknown';
    if (rateLimited(ip)) return json({ error: 'too_many_requests' }, 429);

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: 'bad_json' }, 400);
    }
    const v = validateRequest(body);
    if (!v.ok) return json({ error: 'bad_request', detail: v.error }, 400);

    const result = await generatePlan(env, v.value);
    if (!result.ok) return json({ error: result.error }, result.status);
    return json({ plan: result.plan, source: 'ai' });
  },
};
