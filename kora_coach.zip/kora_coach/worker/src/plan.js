// Pure logic for plan requests: validation, prompt building, and plan repair/validation.
// No network calls here, so it can be unit-tested with plain Node.

export const POSITIONS = ['gk', 'def', 'mid', 'att'];
export const LEVELS = ['beginner', 'intermediate', 'advanced'];
export const GOALS = ['all', 'technique', 'fitness', 'speed', 'shooting'];
export const PLAN_TYPES = ['daily', 'twoWeeks'];
export const EQUIPMENT = ['cones', 'wall', 'ladder', 'gym'];
export const SESSION_MINUTES = [30, 45, 60, 90];

const LEVEL_NUM = { beginner: 1, intermediate: 2, advanced: 3 };
const POS_EN = { gk: 'goalkeeper', def: 'defender', mid: 'midfielder', att: 'attacker/forward' };
const MAIN_CATS = ['technique', 'position', 'fitness'];

// Which days of the week (1..7) are training days for each weekly frequency.
const PATTERNS = {
  3: [1, 3, 5],
  4: [1, 2, 4, 6],
  5: [1, 2, 4, 5, 6],
  6: [1, 2, 3, 5, 6, 7],
};

export function validateRequest(body) {
  if (!body || typeof body !== 'object') return { ok: false, error: 'body must be an object' };
  const age = Number(body.age);
  if (!Number.isInteger(age) || age < 8 || age > 45) return { ok: false, error: 'age must be 8..45' };
  if (!POSITIONS.includes(body.position)) return { ok: false, error: 'bad position' };
  if (!LEVELS.includes(body.level)) return { ok: false, error: 'bad level' };
  if (!GOALS.includes(body.goal)) return { ok: false, error: 'bad goal' };
  if (!PLAN_TYPES.includes(body.planType)) return { ok: false, error: 'bad planType' };
  const sessionMinutes = Number(body.sessionMinutes);
  if (!SESSION_MINUTES.includes(sessionMinutes)) return { ok: false, error: 'bad sessionMinutes' };
  let daysPerWeek = body.daysPerWeek === undefined ? 4 : Number(body.daysPerWeek);
  if (!Number.isInteger(daysPerWeek) || daysPerWeek < 3 || daysPerWeek > 6) {
    return { ok: false, error: 'daysPerWeek must be 3..6' };
  }
  const equipment = body.equipment === undefined ? [] : body.equipment;
  if (!Array.isArray(equipment) || equipment.some((e) => !EQUIPMENT.includes(e))) {
    return { ok: false, error: 'bad equipment' };
  }
  return {
    ok: true,
    value: {
      age,
      position: body.position,
      level: body.level,
      goal: body.goal,
      planType: body.planType,
      daysPerWeek,
      sessionMinutes,
      equipment: [...new Set(equipment)],
    },
  };
}

// true = training day, false = rest day. One entry per plan day.
export function trainingDays(req) {
  if (req.planType === 'daily') return [true];
  const pattern = PATTERNS[req.daysPerWeek] || PATTERNS[4];
  const out = [];
  for (let d = 1; d <= 14; d++) out.push(pattern.includes(((d - 1) % 7) + 1));
  return out;
}

// Exercises this particular player may be given (age, level, equipment, position).
export function eligible(req, catalog) {
  const lv = LEVEL_NUM[req.level];
  return catalog.filter(
    (e) =>
      req.age >= e.minAge &&
      lv >= e.minLevel &&
      e.equip.every((q) => req.equipment.includes(q)) &&
      (e.positions.includes('all') || e.positions.includes(req.position)),
  );
}

export function sessionShape(sessionMinutes) {
  const warm = sessionMinutes <= 30 ? 5 : sessionMinutes <= 45 ? 8 : 10;
  const cool = sessionMinutes <= 30 ? 5 : 8;
  return { warm, cool, mainBudget: sessionMinutes - warm - cool };
}

export function buildPrompt(req, catalog, train, previousProblem) {
  const list = eligible(req, catalog).filter((e) => e.cat !== 'rest');
  const lines = list
    .map((e) => `${e.id} | ${e.name} | ${e.cat} | goals: ${e.goals.join(',') || '-'} | intensity ${e.intensity}`)
    .join('\n');
  const { warm, cool, mainBudget } = sessionShape(req.sessionMinutes);
  const dayLines = train.map((t, i) => `Day ${i + 1}: ${t ? 'TRAIN' : 'REST'}`).join('\n');

  const system = [
    'You are Coach Min (كوتش مين), an experienced Korean-style football (soccer) coach inside a mobile training app.',
    'You ONLY create football training plans. You never discuss anything else.',
    'Output ONLY one JSON object, no markdown, no commentary.',
    'All text values must be in simple Modern Standard Arabic. Coach Min is disciplined, warm and motivating; use the Korean word 화이팅 at most once in coachNote and at most twice in all tips.',
    'Use ONLY exercise ids from the catalog you are given. Never invent exercises or ids.',
    `For every TRAIN day: first task = one warmup exercise (${warm} min), last task = cooldown_stretch (${cool} min), and 2 to 4 main exercises between them whose minutes add up to about ${mainBudget}.`,
    'For REST days: return an empty tasks array.',
    'Vary the exercise combinations from day to day. Match the player goal. Include position-specific exercises when available.',
    'Progression: in a two-week plan, week 2 is slightly harder than week 1 (a little more volume), never more than about 15% more for beginners.',
    'For young players (under 14) keep things playful, technical and light.',
    'JSON schema: {"title": string, "coachNote": string (1-2 sentences), "days": [{"day": number, "focus": string (2-4 words), "tasks": [{"id": string, "minutes": number, "dose": string (e.g. "4 جولات × 20 متراً"), "tip": string (max 14 words)}]}]}',
  ].join('\n');

  let user = [
    `Player: age ${req.age}, position ${POS_EN[req.position]}, level ${req.level}, goal ${req.goal}.`,
    `Plan type: ${req.planType === 'daily' ? 'one day only' : 'two weeks (14 days)'}; session length ${req.sessionMinutes} minutes.`,
    `Schedule (you must return exactly these days):\n${dayLines}`,
    `Catalog (id | name | category | goals | intensity):\n${lines}`,
  ].join('\n\n');
  if (previousProblem) user += `\n\nYour previous answer was rejected: ${previousProblem}. Fix it.`;
  return { system, user };
}

export function parseJsonLoose(text) {
  if (typeof text !== 'string') return null;
  let t = text.trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  try {
    return JSON.parse(t);
  } catch {
    const a = t.indexOf('{');
    const b = t.lastIndexOf('}');
    if (a >= 0 && b > a) {
      try {
        return JSON.parse(t.slice(a, b + 1));
      } catch {
        return null;
      }
    }
    return null;
  }
}

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const clean = (s, max) => (typeof s === 'string' ? s.replace(/\s+/g, ' ').trim().slice(0, max) : '');
const round5 = (n) => Math.max(5, Math.round(n / 5) * 5);

function hydrate(ex, minutes, dose, tip) {
  return {
    id: ex.id,
    name: ex.name,
    cat: ex.cat,
    minutes,
    dose: dose || `${minutes} دقيقة`,
    how: ex.how,
    tip: tip || '',
  };
}

// Turns the model's raw answer into a safe, well-formed plan. Returns {ok:true, plan} or {ok:false, reason}.
export function repairPlan(raw, req, catalog, train) {
  if (!raw || !Array.isArray(raw.days)) return { ok: false, reason: 'missing days array' };
  const byId = new Map(catalog.map((e) => [e.id, e]));
  const allowed = new Set(eligible(req, catalog).map((e) => e.id));
  const rawByDay = new Map();
  for (const d of raw.days) {
    const n = Number(d && d.day);
    if (Number.isInteger(n) && n >= 1 && n <= train.length && !rawByDay.has(n)) rawByDay.set(n, d);
  }

  const { warm, cool, mainBudget } = sessionShape(req.sessionMinutes);
  const warmups = eligible(req, catalog).filter((e) => e.cat === 'warmup');
  const cooldown = byId.get('cooldown_stretch');
  const walk = byId.get('light_recovery_walk');
  const days = [];

  for (let n = 1; n <= train.length; n++) {
    if (!train[n - 1]) {
      days.push({
        day: n,
        rest: true,
        focus: 'يوم راحة 😴',
        tasks: walk ? [hydrate(walk, walk.minutes, `${walk.minutes} دقيقة`, 'الراحة جزء من التدريب')] : [],
      });
      continue;
    }

    const rd = rawByDay.get(n);
    if (!rd || !Array.isArray(rd.tasks)) return { ok: false, reason: `day ${n} is missing` };

    const seen = new Set();
    const picked = [];
    for (const t of rd.tasks) {
      const ex = byId.get(String(t && t.id));
      if (!ex || !allowed.has(ex.id) || seen.has(ex.id)) continue;
      seen.add(ex.id);
      picked.push({ ex, minutes: Number(t.minutes) || ex.minutes, dose: clean(t.dose, 60), tip: clean(t.tip, 140) });
    }

    let mains = picked.filter((p) => MAIN_CATS.includes(p.ex.cat));
    // At most two high-intensity exercises in one session.
    let high = 0;
    mains = mains.filter((p) => (p.ex.intensity >= 3 ? ++high <= 2 : true));
    mains = mains.slice(0, 4);
    while (mains.length > 2 && mains.length * 5 > mainBudget) mains.pop();
    if (mains.length < 2) return { ok: false, reason: `day ${n} has fewer than 2 valid main exercises` };

    // Rescale the main exercises so the session matches the requested length.
    const sum = mains.reduce((s, p) => s + clamp(p.minutes, 5, 40), 0);
    const factor = mainBudget / sum;
    mains.forEach((p) => (p.minutes = round5(clamp(p.minutes, 5, 40) * factor)));
    let diff = mainBudget - mains.reduce((s, p) => s + p.minutes, 0);
    const biggest = mains.reduce((a, b) => (b.minutes > a.minutes ? b : a));
    if (biggest.minutes + diff >= 5) biggest.minutes += diff;

    const w = picked.find((p) => p.ex.cat === 'warmup');
    const warmEx = w ? w.ex : warmups[(n - 1) % warmups.length];
    const c = picked.find((p) => p.ex.cat === 'recovery');
    const coolEx = c ? c.ex : cooldown;
    if (!warmEx || !coolEx) return { ok: false, reason: 'catalog is missing warmup or cooldown' };

    const tasks = [
      hydrate(warmEx, warm, `${warm} دقيقة`, w ? w.tip : ''),
      ...mains.map((p) => hydrate(p.ex, p.minutes, p.dose, p.tip)),
      hydrate(coolEx, cool, `${cool} دقيقة`, c ? c.tip : ''),
    ];
    days.push({ day: n, rest: false, focus: clean(rd.focus, 40) || 'تدريب اليوم', tasks });
  }

  return {
    ok: true,
    plan: {
      title: clean(raw.title, 60) || (req.planType === 'daily' ? 'خطة اليوم مع كوتش مين' : 'خطة أسبوعين مع كوتش مين'),
      coachNote: clean(raw.coachNote, 220) || '화이팅! خطوة صغيرة كل يوم تصنع نجماً ⭐',
      days,
    },
  };
}
